
package interfaces;

public interface precios {
    
    public abstract double calcularPrecioVenta();
}
